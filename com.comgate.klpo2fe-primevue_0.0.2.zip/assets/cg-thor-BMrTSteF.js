const o="/cg-thor.svg";export{o as _};
