System.register([],function(t,n){"use strict";return{execute:function(){t("u",async function(t){try{return[null,await t().catch(t=>{throw t})]}catch(n){return[n,null]}})}}});
