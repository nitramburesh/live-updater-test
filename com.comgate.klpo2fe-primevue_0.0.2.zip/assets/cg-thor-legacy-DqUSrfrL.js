System.register([],function(t,e){"use strict";return{execute:function(){t("_","/cg-thor.svg")}}});
