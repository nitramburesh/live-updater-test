import{W as n}from"./index-_vHg9sW2.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
